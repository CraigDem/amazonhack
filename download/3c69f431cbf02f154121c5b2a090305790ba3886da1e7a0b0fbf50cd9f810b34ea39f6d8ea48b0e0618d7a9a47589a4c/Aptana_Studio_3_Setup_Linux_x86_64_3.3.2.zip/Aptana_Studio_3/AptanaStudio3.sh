#!/bin/bash
export UBUNTU_MENUPROXY=0
./AptanaStudio3