##
# For RubyGems backwards compatibility

module RDoc::RI::Formatter # :nodoc:
end
